from django.http import FileResponse
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from .models import UploadedFile
from .serializers import FileSerializer
from django.http import HttpResponseBadRequest
from rest_framework.permissions import IsAuthenticated

from rest_framework.authtoken.models import Token

class FileViewSet(viewsets.ModelViewSet):
    authentication_classes = [TokenAuthentication]
    # permission_classes=[IsAuthenticated]
    
    
    '''
    if you will uncomment this above line of code when you clicked on web link like http://127.0.0.1:8000/files/ you can not upload a new file
     the error will show= "GET /files/ HTTP/1.1" 200 14224
     Unauthorized: /files/ in command and 
     
     on web 
    Unauthorized: creadintail is not allowed or not provide
    
    
    used postman for check file 
    
    token is =token f07eead15e96a9d0908cf0e326bb63df6f334f04
    link is http://127.0.0.1:8000/files/
    
    '''
  
    
    queryset = UploadedFile.objects.all()
    serializer_class = FileSerializer

    @action(detail=False, methods=['post'])
    def upload_file(self, request):
        user = request.user if request.user.is_authenticated else None

        if 'file' in request.FILES:
            uploaded_file = request.FILES['file']
            
#pdf file uploaded for testing purpose
            if uploaded_file.name.lower().endswith('.docx','.xlsx','pptx'):
                file_instance = UploadedFile(user=user, file=uploaded_file)
                file_instance.save()
                return Response({'message': 'file uploaded successfully.'}, status=status.HTTP_201_CREATED)
            else:
                return Response({'message': 'Invalid file type. files are allowed.'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'message': 'File not provided.'}, status=status.HTTP_400_BAD_REQUEST)

   